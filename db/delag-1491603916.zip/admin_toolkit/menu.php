<ul>
  <li><a href="usuario.php">USUARIO</a></li>
  <li><a href="usuario_editar_clave.php">EDITAR CLAVE</a></li>
  <li><a href="marca.php">MARCA</a></li>
  <li><a href="servicio.php">SERVICIO</a></li>
  <li><a href="taller.php">TALLER</a></li>
  <li><a href="calificacion.php">CALIFICACION</a></li>
  <li><a href="faq.php">FAQ</a></li>
  <li><a href="banner.php">BANNER</a></li>
  <li><a href="#"></a></li>
</ul>
